from django.apps import AppConfig


class AppdopedroConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appdopedro'
